#### [RX_UPLOADER-BOT](https://t.me/rx_uploader_bot)

[![Size](https://img.shields.io/github/repo-size/Clinton-Abraham/UPLOADER-BOT?style=flat-square&color=green)](https://github.com/Clinton-Abraham/UPLOADER-BOT)

---

Telegram RoBot to Upload Links.

**Features**:

👉 Upload [yt-dlp Supported Links](https://ytdl-org.github.io/youtube-dl/supportedsites.html) to Telegram.

👉 Upload HTTP/HTTPS as File/Video to Telegram.

👉 Upload zee5, sony.live, voot and much more.

👉 Inline torrent search support.

👉  Permanent thumbnail Support.

👉 Broadcast message.

**Heroku Buildpacks**
```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
```
heroku/python
```

```
⚠️ AFTER FORK EDIT DEPLOY BUTTON REPLACE WITH YOUR REPO LINK ⚙️
```

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=#your repo link)

## BOT COMMANDS

* start - 👻 Check I'm alive or dead
* help - 📝 How to use this robot
* search - 🚸 Torrent search
* broadcast - 💌 Send message to users
* total - 👨‍👨‍👦‍👦 To get total users count
* viewthumbnail - 🌌 Current Thumbnail
* delthumbnail - 🎇 Delete thumbnail


## Credits, and Thanks to

@Rvx

http://t.me/RXbots
